/*
 * faceDetect.cpp
 *
 *  Created on: 2018年12月30日
 *      Author: owen
 */
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/objdetect.hpp>

#include <iostream>

using namespace cv;
using namespace std;

void detectAndDisplay(Mat frame,Mat glasses, Mat dogEars);
Mat maskImg(Mat srcImageIn, Size size);

CascadeClassifier face_cascade;
CascadeClassifier eyes_cascade;

int main(){

	//path to face cascade xml file
	String face_cascade_name = "./src/haarcascade_frontalface_default.xml";
	//path to eyes cascade xml file
	String eyes_cascade_name = "./src/haarcascade_eye.xml";

	//prepare sunglasses
	Mat glasses = imread("./src/sunglass.jpg");
	Mat dogEars = imread("./src/dog_ear.jpg");


	//-- 1. Load the cascades
	if( !face_cascade.load( face_cascade_name ) )
	{
		cout << "--(!)Error loading face cascade\n";
		return -1;
	};

	if( !eyes_cascade.load( eyes_cascade_name ) )
	{
		cout << "--(!)Error loading eyes cascade\n";
		return -1;
	};
	//check if read successfully


	int camera_device = 0; //camera ID, 0 be the first device
	VideoCapture capture;

	//-- 2. Read the video stream
	capture.open( camera_device );
	if ( ! capture.isOpened() )
	{
		cout << "--(!)Error opening video capture\n";
		return -1;
	}
	Mat frame;
	while ( capture.read(frame) )
	{
		if( frame.empty() )
		{
			cout << "--(!) No captured frame -- Break!\n";
			break;
		}

		//-- 3. Apply the classifier to the frame
		detectAndDisplay(frame, glasses, dogEars);
		if( waitKey(1) == 2 )	//control the delay
		{
			break; // escape
		}

	}
	return 0;
}


void detectAndDisplay(Mat frame, Mat glasses, Mat dogEars)
{
	Mat frame_gray;
	cvtColor( frame, frame_gray, COLOR_BGR2GRAY );
	equalizeHist( frame_gray, frame_gray );

	int mode = 0;

	//-- Detect faces
	std::vector<Rect> faces;
	face_cascade.detectMultiScale( frame_gray, faces );
	for ( size_t i = 0; i < faces.size(); i++ )
	{
		Point corner1( faces[i].x, faces[i].y );
		Point corner2( faces[i].x + faces[i].width, faces[i].y + faces[i].height);

		Mat faceROI = frame_gray( faces[i] );
		//-- In each face, detect eyes
		std::vector<Rect> eyes;
		eyes_cascade.detectMultiScale( faceROI, eyes );

		switch(mode){
		case 0:
			//put in sunglasses
			if(!faces[i].empty() && !eyes.empty()){
	        	Size size(faces[i].width,int(0.25*faces[i].height));
	        	Mat mask = maskImg(glasses, size);
	        	resize(glasses,glasses,size);

	        	Rect roi(faces[i].x - 10,faces[i].y + eyes[0].y,mask.size().width, mask.size().height); //top x, top y, width, height
	        	Mat frame_roi = frame(roi);
	        	glasses.copyTo(frame_roi,mask);
			}
			break;

		case 1:
			//put in dog ears (222 × 180)
			if(!faces[i].empty() && !eyes.empty()){
				Size size(int(1.5*faces[i].width),int(1.3*faces[i].height));
				Mat mask = maskImg(dogEars, size);
				resize(dogEars,dogEars,size);
				if(faces[i].x + int(faces[i].width/2) - int(mask.size().width/2) > 0 && faces[i].x + mask.size().width < frame.size().width){
					if(faces[i].y + mask.size().height < frame.size().height){
						Rect roi(faces[i].x + int(faces[i].width/2) - int(mask.size().width/2),faces[i].y,mask.size().width, mask.size().height); //top x, top y, width, height
						Mat frame_roi = frame(roi);
						dogEars.copyTo(frame_roi,mask);
					}
				}
			}
			break;

		}

	}

	//-- Show what you got
	imshow( "Capture - Face detection", frame );

}

Mat maskImg(Mat srcImageIn, Size size){
	Mat maskin;
	Mat mask;
	Mat srcImage;

	cvtColor(srcImageIn, maskin,COLOR_BGR2GRAY);
	resize(maskin,mask,size);
	resize(srcImageIn,srcImage,size);
	bitwise_not(mask, mask);//inverse mask, white(255) to black(0)
	threshold(mask, mask, 100, 255, THRESH_BINARY);
	return mask;
}
