#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //Setup graphic
    ui->graphicsView->setScene(new QGraphicsScene(this));
    ui->graphicsView->scene()->addItem(&pixmap);
    ui->graphicsView->fitInView(&pixmap, Qt::KeepAspectRatio);

    if(!filter.loadfiles()){
        return;
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_glassesButton_clicked()
{
    select = 1;
    Mat frame;
    while(video.isOpened())
    {
        video >> frame;
        if(!frame.empty())
        {

            frame = filter.Filter(frame, select);

            // display frames
            QImage qimg(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
            pixmap.setPixmap( QPixmap::fromImage(qimg.rgbSwapped()) );
        }
        qApp->processEvents();
    }
}

void MainWindow::on_dogButton_clicked()
{
    select = 2;
    Mat frame;
    while(video.isOpened())
    {
        video >> frame;
        if(!frame.empty())
        {

            frame = filter.Filter(frame, select);

            // display frames
            QImage qimg(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
            pixmap.setPixmap( QPixmap::fromImage(qimg.rgbSwapped()) );
        }
        qApp->processEvents();
    }
}

void MainWindow::on_startButton_clicked()
{
    if(!video.open(camera_ID))
    {
        QMessageBox::critical(this,
                              "Camera Error",
                              "Make sure you entered a correct camera index,"
                              "<br>or that the camera is not being accessed by another program!");
        return;
    }


    Mat frame;
    while(video.isOpened())
    {
        video >> frame;
        if(!frame.empty())
        {

            frame = filter.Filter(frame, select);

            // display frames
            QImage qimg(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
            pixmap.setPixmap( QPixmap::fromImage(qimg.rgbSwapped()) );
        }
        qApp->processEvents();
    }
}
