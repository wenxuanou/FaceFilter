#ifndef FACEFILTER_H
#define FACEFILTER_H

#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;


class FaceFilter{
public:
    explicit FaceFilter();
    ~FaceFilter();

    bool loadfiles();
    Mat Filter(Mat Frame, int select);

private:

    const String face_cascade_name = "/Users/owen/Documents/Qt_workspace/OpenCv_VideoProc_Ver2/haarcascade_frontalface_default.xml";
    const String eyes_cascade_name = "/Users/owen/Documents/Qt_workspace/OpenCv_VideoProc_Ver2/haarcascade_eye.xml";
    const String glasses_name = "/Users/owen/Documents/Qt_workspace/OpenCv_VideoProc_Ver2/sunglass.jpg";
    const String dog_name = "/Users/owen/Documents/Qt_workspace/OpenCv_VideoProc_Ver2/dog_ear.jpg";

    Mat glasses;
    Mat dogEars;
    Mat frame;

    VideoCapture capture;
    CascadeClassifier face_cascade;
    CascadeClassifier eyes_cascade;

    bool loadCascade ();
    Mat maskImg(Mat srcImageIn, Size size);

};

#endif // FACEFILTER_H
