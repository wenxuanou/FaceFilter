#include"facefilter.h"


FaceFilter::FaceFilter(){
}

FaceFilter::~FaceFilter()
{

}

bool FaceFilter::loadfiles(){

    if(!loadCascade()){
        return false;
    }else{
        glasses = imread(glasses_name);
        dogEars = imread(dog_name);
        //imshow("glasses", glasses);
        return true;
    }
}


bool FaceFilter::loadCascade (){
    bool faceLoadSuccess = false;
    bool eyesLoadSuccess = false;

    if( !face_cascade.load( face_cascade_name ) )
    {
        cout << "--(!)Error loading face cascade\n";
    }else{
        faceLoadSuccess = true;
    }

    if( !eyes_cascade.load( eyes_cascade_name ) )
    {
        cout << "--(!)Error loading eyes cascade\n";
    }else{
        eyesLoadSuccess = true;
    }

    return faceLoadSuccess && eyesLoadSuccess;
}

Mat FaceFilter::Filter(Mat frame, int select){

    Mat frame_gray;
    cvtColor( frame, frame_gray, COLOR_BGR2GRAY );
    equalizeHist( frame_gray, frame_gray );

    //-- Detect faces
    std::vector<Rect> faces;
    face_cascade.detectMultiScale( frame_gray, faces );
    for ( size_t i = 0; i < faces.size(); i++ )
    {
        Point corner1( faces[i].x, faces[i].y );
        Point corner2( faces[i].x + faces[i].width, faces[i].y + faces[i].height);

        Mat faceROI = frame_gray( faces[i] );
        //-- In each face, detect eyes
        std::vector<Rect> eyes;
        eyes_cascade.detectMultiScale( faceROI, eyes );

        switch(select){
        case 0:
            break;

        case 1:
            //put in sunglasses
            if(!faces[i].empty() && !eyes.empty()){
                Size size(faces[i].width,int(0.25*faces[i].height));
                Mat mask = maskImg(glasses, size);
                resize(glasses,glasses,size);

                if(faces[i].x + mask.size().width  < frame.size().height){
                    if(faces[i].y + mask.size().height + int(faces[i].y/2) < frame.size().height){
                        Rect roi(faces[i].x ,faces[i].y + + int(faces[i].y/2),mask.size().width, mask.size().height); //top x, top y, width, height
                        Mat frame_roi = frame(roi);
                        glasses.copyTo(frame_roi,mask);
                    }
                }
            }
            break;

        case 2:
            //put in dog ears (222 × 180)
            if(!faces[i].empty() && !eyes.empty()){
                Size size(int(1.5*faces[i].width),int(1.3*faces[i].height));
                Mat mask = maskImg(dogEars, size);
                resize(dogEars,dogEars,size);

                if(faces[i].x + int(faces[i].width/2) - int(mask.size().width/2) > 0 && faces[i].x + mask.size().width < frame.size().width){
                    if(faces[i].y + mask.size().height < frame.size().height){
                        Rect roi(faces[i].x + int(faces[i].width/2) - int(mask.size().width/2),faces[i].y,mask.size().width, mask.size().height); //top x, top y, width, height
                        Mat frame_roi = frame(roi);
                        dogEars.copyTo(frame_roi,mask);
                    }
                }
            }
            break;
        }

    }
    return frame;
}

Mat FaceFilter::maskImg(Mat srcImageIn, Size size){
    Mat maskin;
    Mat mask;
    Mat srcImage;

    cvtColor(srcImageIn, maskin, COLOR_BGR2GRAY);
    cv::resize(maskin,mask,size);
    cv::resize(srcImageIn,srcImage,size);
    bitwise_not(mask, mask);//inverse image, white(255) to black(0)
    threshold(mask, mask, 100, 255, THRESH_BINARY);
    return mask;
}
