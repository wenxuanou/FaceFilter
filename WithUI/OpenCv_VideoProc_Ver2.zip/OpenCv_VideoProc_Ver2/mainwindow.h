#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QImage>
#include <QPixmap>
#include <QCloseEvent>
#include <QMessageBox>

#include <facefilter.h>

namespace Ui {
class MainWindow;
}

using namespace cv;


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_glassesButton_clicked();

    void on_dogButton_clicked();

    void on_startButton_clicked();

private:
    Ui::MainWindow *ui;
    QGraphicsPixmapItem pixmap;
    cv::VideoCapture video;
    FaceFilter filter;

    Mat frame;
    const int camera_ID = 0;    //camera ID, 0 be the first device
    int select = 0; //0 no filter; 1 sunglasses; 2 dogface
};

#endif // MAINWINDOW_H
